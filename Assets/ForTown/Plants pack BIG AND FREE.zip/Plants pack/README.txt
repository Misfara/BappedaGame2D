﻿Hello there. I'm Arthur, someone who created this pack (a.k.a SirCatIsCat). You've probably found this plants somewhere in social media. It's created for you to use it in whatever you want. And if you will, I'll really appreciate it if you mention me in your project. Thank you 
My contacts, so you can hire me:
Telegram: @SirCatIsCat or @Frirenuuu
Instagram: sir_cat_is_cat https://www.instagram.com/sir_cat_is_cat?igsh=cmM5amdoZGE2aDk= 
Discord: sir_catiscat
Здравствуй. Я создатель данного пака (SirCatIsCat). Ты наверное нашёл эту растительность в какой-нибудь соцсети. Я сделал его для того, чтобы ты мог его где-нибудь использовать. Абсолютно бесплатно. Если ты действительно им воспользуешься, я буду очень небольшому упоминанию меня где-нибудь в твоём проекте. Спасибо.
Мои контакты, если у тебя есть желание меня нанять:)
Telegram: @SirCatIsCat or @Frirenuuu
Instagram: sir_cat_is_cat https://www.instagram.com/sir_cat_is_cat?igsh=cmM5amdoZGE2aDk= 
Discord: sir_catiscat

ᕙ⁠(⁠＠⁠°⁠▽⁠°⁠＠⁠)⁠ᕗ


